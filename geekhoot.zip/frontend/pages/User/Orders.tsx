import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Package, 
  Truck, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  Box, 
  Ship, 
  MapPin,
  ExternalLink,
  Info,
  ArrowRight,
  ClipboardCheck,
  Search,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import api from '@/src/services/api';
import { OrderListSkeleton } from '@/src/components/common/Skeleton';
import { generateTrackingTimeline } from '@/src/utils/trackingEngine';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

const STATUS_CONFIG: Record<string, { color: string, icon: any, label: string, step: number }> = {
  PENDING: { color: 'bg-yellow-100 dark:bg-yellow-950/40 text-yellow-700 dark:text-yellow-400', icon: Clock, label: 'Pending', step: 0 },
  CONFIRMED: { color: 'bg-blue-100 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400', icon: CheckCircle2, label: 'Confirmed', step: 1 },
  PACKED: { color: 'bg-purple-100 dark:bg-purple-950/40 text-purple-700 dark:text-purple-400', icon: Box, label: 'Packed', step: 2 },
  SHIPPED: { color: 'bg-indigo-100 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-400', icon: Ship, label: 'Shipped', step: 3 },
  DELIVERED: { color: 'bg-green-100 dark:bg-green-950/40 text-green-700 dark:text-green-400', icon: Truck, label: 'Delivered', step: 4 },
  CANCELLED: { color: 'bg-red-100 dark:bg-red-950/40 text-red-700 dark:text-red-400', icon: Clock, label: 'Cancelled', step: -1 },
};

export default function Orders() {
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const navigate = useNavigate();

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['my-orders'],
    queryFn: async () => {
      const { data } = await api.get('/orders/my');
      return data;
    },
  });

  if (isLoading) return <OrderListSkeleton />;

  const handleDownloadInvoice = async (order: any, e?: React.MouseEvent) => {
    e?.stopPropagation();
    try {
      const { data } = await api.post('/orders/invoice', { orderCodes: [order.orderCode] });
      window.open(data.invoiceUrl, '_blank');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to download invoice');
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 bg-[#f1f3f6] dark:bg-zinc-950 min-h-screen text-gray-900 dark:text-white">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">My Orders</h1>
          <p className="text-sm text-gray-500 dark:text-zinc-400 font-medium">Manage and track your recent orders</p>
        </div>
        <div className="bg-white dark:bg-zinc-900 px-4 py-2 rounded shadow-sm border border-gray-100 dark:border-zinc-800 flex items-center gap-2">
          <span className="text-sm font-bold text-blue-600 dark:text-blue-400">{orders.length}</span>
          <span className="text-sm text-gray-400 dark:text-zinc-500">Total Orders</span>
        </div>
      </div>

      {orders.length > 0 ? (
        <div className="space-y-4">
          {orders.map((order: any, i: number) => {
            const status = STATUS_CONFIG[order.status] || STATUS_CONFIG.PENDING;
            return (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05, duration: 0.25, ease: 'easeOut' }}
                style={{ willChange: 'transform, opacity' }}
              >
                <Card 
                  onClick={() => setSelectedOrder(order)}
                  className="rounded-lg border border-gray-100 dark:border-zinc-800 shadow-sm hover:shadow-md cursor-pointer transition-all bg-white dark:bg-zinc-900 overflow-hidden"
                >
                  <CardContent className="p-4 md:p-6">
                    <div className="flex flex-col md:flex-row gap-6">
                      {/* Product Info */}
                      <div className="w-24 h-24 md:w-32 md:h-32 rounded border border-gray-50 dark:border-zinc-800 bg-gray-50 dark:bg-zinc-800 overflow-hidden shrink-0 mx-auto md:mx-0">
                        <img 
                          src={(Array.isArray(order.product.images) && order.product.images.length > 0) ? order.product.images[0] : ''} 
                          alt={order.product.name} 
                          className="w-full h-full object-cover" 
                        />
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center justify-between gap-4 mb-3">
                          <div className="flex items-center gap-2">
                            <Badge className={`${status.color} border-none font-bold text-xs rounded-sm px-2.5 py-0.5`}>
                              {status.label}
                            </Badge>
                            <span className="text-xs text-gray-400 dark:text-zinc-500 font-bold">
                              ID: {order.orderCode || order.id.slice(-8).toUpperCase()}
                            </span>
                          </div>
                          <span className="text-sm font-bold text-gray-900 dark:text-white">₹{order.totalAmount.toLocaleString()}</span>
                        </div>
                        
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1 line-clamp-1">{order.product.name}</h3>
                        <p className="text-sm text-gray-500 dark:text-zinc-400 mb-4">
                          Qty: <span className="font-bold">{order.quantity}</span>
                          {order.size && <span className="ml-2 font-bold">• Size: {order.size}</span>}
                        </p>
                        
                        <div className="flex flex-wrap items-center gap-4 text-xs text-gray-400 dark:text-zinc-500 font-medium">
                          <div className="flex items-center gap-1.5">
                             <Calendar className="w-3.5 h-3.5" />
                             Ordered on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                          </div>
                           {order.trackingId && (
                            <div className="flex items-center gap-1.5 text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/30 px-2 py-0.5 rounded">
                               <Truck className="w-3.5 h-3.5" />
                               {order.courier}: {order.trackingId}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-center gap-2 border-t md:border-t-0 md:border-l border-gray-50 dark:border-zinc-800 pt-4 md:pt-0 md:pl-6">
                         <Button
                           variant="outline"
                           onClick={(e) => handleDownloadInvoice(order, e)}
                           className="border-gray-200 dark:border-zinc-700 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-zinc-800 font-bold gap-1.5 cursor-pointer transition-all"
                         >
                           <Download className="w-4 h-4" /> Invoice
                         </Button>
                         <Button 
                           variant="ghost" 
                           onClick={(e) => {
                             e.stopPropagation();
                             setSelectedOrder(order);
                           }}
                           className="text-[#e0122a] font-bold hover:bg-red-50 dark:hover:bg-red-950/30 gap-2 cursor-pointer transition-all"
                         >
                           View Details <ArrowRight className="w-4 h-4" />
                         </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-20 bg-white dark:bg-zinc-900 rounded-lg border border-gray-100 dark:border-zinc-800 shadow-sm">
           <Package className="w-16 h-16 text-gray-100 dark:text-zinc-700 mx-auto mb-6" />
           <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">No Orders Found</h3>
           <p className="text-sm text-gray-400 dark:text-zinc-500 mb-8 max-w-xs mx-auto font-medium">Looks like you haven't placed any orders yet. Explore our products and start shopping.</p>
           <Button onClick={() => navigate('/products')} className="bg-[#c00e22] hover:bg-[#e0122a] text-white font-bold h-11 px-8 rounded-sm shadow-sm border-none">Start Shopping</Button>
        </div>
      )}

      {/* Order Detail Modal */}
      <Dialog open={!!selectedOrder} onOpenChange={(open) => !open && setSelectedOrder(null)}>
        <DialogContent className="max-w-2xl rounded-lg p-0 border-none max-h-[90vh] overflow-y-auto bg-white dark:bg-zinc-900 shadow-2xl">
          {selectedOrder && (
            <div className="relative">
              {/* Header */}
              <div className="p-6 border-b border-gray-100 dark:border-zinc-800 flex items-center justify-between bg-gray-50 dark:bg-zinc-800">
                 <div>
                    <h2 className="text-lg font-bold text-gray-900 dark:text-white">Order Details</h2>
                    <p className="text-xs text-gray-500 dark:text-zinc-400 font-medium">ID: {selectedOrder.orderCode || selectedOrder.id.slice(-8).toUpperCase()}</p>
                 </div>
                 <div className="flex items-center gap-2">
                   <Button
                     size="sm"
                     variant="outline"
                     onClick={(e) => handleDownloadInvoice(selectedOrder, e)}
                     className="border-gray-200 dark:border-zinc-700 text-gray-700 dark:text-gray-300 hover:bg-white dark:hover:bg-zinc-700 font-bold gap-1.5 cursor-pointer transition-all"
                   >
                     <Download className="w-3.5 h-3.5" /> Invoice
                   </Button>
                   <Badge className={`${STATUS_CONFIG[selectedOrder.status]?.color || 'bg-gray-100 dark:bg-zinc-700'} border-none font-bold text-xs px-3 py-1 rounded-sm`}>
                      {selectedOrder.status}
                   </Badge>
                 </div>
              </div>

              <div className="p-6 space-y-8">
                {/* Tracker */}
                <div className="pt-4 pb-8 border-b border-gray-50 dark:border-zinc-800">
                  <div className="relative flex justify-between">
                    <div className="absolute top-5 left-0 w-full h-1 bg-gray-100 dark:bg-zinc-800 rounded-full"></div>
                    <div 
                      className="absolute top-5 left-0 h-1 bg-[#e0122a] rounded-full transition-all duration-700"
                      style={{ width: `${(STATUS_CONFIG[selectedOrder.status]?.step || 0) * 25}%` }}
                    ></div>
                    
                    {[
                      { step: 0, icon: Clock, label: 'Placed' },
                      { step: 1, icon: CheckCircle2, label: 'Confirmed' },
                      { step: 2, icon: Box, label: 'Packed' },
                      { step: 3, icon: Ship, label: 'Shipped' },
                      { step: 4, icon: Truck, label: 'Delivered' }
                    ].map((item) => {
                      const isActive = (STATUS_CONFIG[selectedOrder.status]?.step || 0) >= item.step;
                      return (
                        <div key={item.step} className="flex flex-col items-center z-10">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 border-2 ${isActive ? 'bg-[#e0122a] border-[#e0122a] text-white shadow-md' : 'bg-white dark:bg-zinc-900 border-gray-100 dark:border-zinc-700 text-gray-300 dark:text-zinc-600'}`}>
                            <item.icon className="w-5 h-5" />
                          </div>
                          <p className={`mt-2 text-[10px] font-bold ${isActive ? 'text-[#e0122a]' : 'text-gray-400 dark:text-zinc-500'}`}>
                            {item.label}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Dynamic Shipment Radar Logs */}
                {selectedOrder.trackingId && (() => {
                  const trackingInfo = generateTrackingTimeline(
                    selectedOrder.trackingId, 
                    selectedOrder.status, 
                    selectedOrder.courier, 
                    selectedOrder.createdAt
                  );
                  return (
                    <div className="bg-slate-50 dark:bg-zinc-800 border border-slate-100 dark:border-zinc-700 rounded-xl p-5 space-y-4">
                      {/* Carrier Banner Header */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-zinc-900 p-3.5 rounded-lg border border-slate-100 dark:border-zinc-700 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest block font-mono">Verified Logistics Stream</span>
                          <span className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                            <Truck className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                            {trackingInfo.carrier}
                          </span>
                        </div>
                        <div className="flex flex-col sm:items-end space-y-1">
                          <span className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest block font-mono">Tracking Code</span>
                          <div className="flex items-center gap-1.5">
                            <code className="text-xs font-mono font-bold text-gray-700 dark:text-zinc-300 bg-gray-50 dark:bg-zinc-800 px-2 py-0.5 rounded border border-gray-100 dark:border-zinc-700">{trackingInfo.trackingId}</code>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-6 w-6 p-0 text-gray-400 dark:text-zinc-500 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-50 dark:hover:bg-zinc-700 border-none cursor-pointer"
                              title="Copy Tracking ID"
                              onClick={() => {
                                navigator.clipboard.writeText(trackingInfo.trackingId);
                                toast.success('Tracking ID copied to clipboard!');
                              }}
                            >
                              <ClipboardCheck className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </div>
                      </div>

                      {/* Diagnostic Status Box */}
                      <div className="grid grid-cols-2 gap-4 bg-white dark:bg-zinc-900 p-3.5 rounded-lg border border-slate-100 dark:border-zinc-700 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest block">Live Status Radar</span>
                          <span className={`inline-block text-xs font-bold px-2.5 py-1 rounded border-none ${trackingInfo.statusColor}`}>
                            {trackingInfo.statusLabel}
                          </span>
                        </div>
                        <div className="space-y-1">
                          <span className="text-[10px] font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest block">Estimated Arrival</span>
                          <span className="text-xs font-bold text-gray-800 dark:text-zinc-200 font-mono block">
                            {trackingInfo.estimatedDelivery}
                          </span>
                        </div>
                      </div>

                      {/* Vertical Tracker Milestones Stepper */}
                      <div className="space-y-4 pt-1 bg-white dark:bg-zinc-900 p-4 h-[220px] overflow-y-auto rounded-lg border border-slate-100 dark:border-zinc-700 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
                        <h4 className="text-xs font-bold text-gray-500 dark:text-zinc-400 uppercase tracking-widest border-b border-gray-50 dark:border-zinc-800 pb-2 flex items-center gap-1.5 sticky top-0 bg-white dark:bg-zinc-900 z-10">
                          <MapPin className="w-4 h-4 text-[#e0122a]" /> Transit Checkpoint Milestones
                        </h4>
                        <div className="relative pl-6 border-l border-blue-105 dark:border-blue-900/50 space-y-6 mt-2">
                            {trackingInfo.milestones.map((log, idx) => {
                              const isLatest = idx === 0;
                              return (
                                <div key={idx} className="relative">
                                  {/* Milestone Pin dot */}
                                  <div className={`absolute -left-[30px] top-0.5 w-4 h-4 rounded-full border-2 bg-white dark:bg-zinc-900 flex items-center justify-center ${isLatest ? 'border-[#e0122a]' : 'border-blue-400 dark:border-blue-700'}`}>
                                    <div className={`w-1.5 h-1.5 rounded-full ${isLatest ? 'bg-[#e0122a] animate-pulse' : 'bg-blue-400 dark:bg-blue-700'}`}></div>
                                  </div>

                                  {/* Label and Content */}
                                  <div className="space-y-1">
                                    <div className="flex flex-wrap items-center justify-between gap-1.5">
                                      <span className={`text-[11px] font-bold ${isLatest ? 'text-[#e0122a]' : 'text-gray-800 dark:text-zinc-200'}`}>
                                        {log.location}
                                      </span>
                                      <span className="text-[10px] font-mono text-gray-400 dark:text-zinc-500 whitespace-nowrap">
                                        {log.timestamp}
                                      </span>
                                    </div>
                                    <p className="text-xs text-slate-500 dark:text-zinc-400 leading-relaxed font-medium">
                                      {log.description}
                                    </p>
                                  </div>
                                </div>
                              );
                            })}
                        </div>
                      </div>

                      {/* Help/Hotline Footer */}
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pt-2 text-[11px] text-gray-400 dark:text-zinc-500 font-medium border-t border-slate-100 dark:border-zinc-700">
                        <span>Need route support? Courier Helpline: <span className="font-bold text-gray-700 dark:text-zinc-300 font-mono">{trackingInfo.carrierSupportPhone}</span></span>
                        <span className="text-[9px] uppercase tracking-widest bg-red-50 dark:bg-red-950/30 text-[#e0122a] px-2 py-0.5 rounded font-bold">Autodetected {trackingInfo.carrier}</span>
                      </div>
                    </div>
                  );
                })()}

                {/* Tracking & Product */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="space-y-4">
                      <h4 className="text-xs font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest">Delivery Address</h4>
                      <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded border border-gray-100 dark:border-zinc-700">
                         <p className="font-bold text-gray-900 dark:text-white text-sm mb-1">{selectedOrder.user?.name}</p>
                         <p className="text-sm text-gray-600 dark:text-zinc-300 leading-relaxed mb-2">{selectedOrder.user?.address}</p>
                         <p className="text-xs font-bold text-gray-400 dark:text-zinc-500">Mobile: {selectedOrder.user?.phone}</p>
                      </div>
                   </div>
                   
                   <div className="space-y-4">
                      <h4 className="text-xs font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest">Pricing Details</h4>
                      <div className="bg-gray-50 dark:bg-zinc-800 p-4 rounded border border-gray-100 dark:border-zinc-700 space-y-2">
                         <div className="flex justify-between text-sm">
                            <span className="text-gray-500 dark:text-zinc-400">List Price</span>
                            <span className="text-gray-900 dark:text-white font-medium">₹{(selectedOrder.totalAmount * 1.2).toLocaleString()}</span>
                         </div>
                         <div className="flex justify-between text-sm">
                            <span className="text-gray-500 dark:text-zinc-400">Discount</span>
                            <span className="text-green-600 dark:text-green-400 font-medium">-₹{(selectedOrder.totalAmount * 0.2).toLocaleString()}</span>
                         </div>
                         <Separator className="bg-gray-200 dark:bg-zinc-700" />
                         <div className="flex justify-between text-sm font-bold">
                            <span className="text-gray-900 dark:text-white">Total Amount</span>
                            <span className="text-gray-900 dark:text-white">₹{selectedOrder.totalAmount.toLocaleString()}</span>
                         </div>
                      </div>
                   </div>
                </div>

                <div className="border-t border-gray-50 dark:border-zinc-800 pt-8">
                   <h4 className="text-xs font-bold text-gray-400 dark:text-zinc-500 uppercase tracking-widest mb-4">Item Details</h4>
                   <div className="flex gap-6 p-4 rounded-lg border border-gray-100 dark:border-zinc-800">
                      <div className="w-20 h-20 rounded bg-gray-50 dark:bg-zinc-800 border border-gray-50 dark:border-zinc-700 overflow-hidden shrink-0">
                         <img src={(Array.isArray(selectedOrder.product.images) && selectedOrder.product.images.length > 0) ? selectedOrder.product.images[0] : ''} 
                            alt={selectedOrder.product.name} 
                            className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1">
                         <h5 className="font-bold text-gray-900 dark:text-white mb-1">{selectedOrder.product.name}</h5>
                         <p className="text-xs text-gray-500 dark:text-zinc-400 mb-2">Category: {selectedOrder.product.category}</p>
                         <div className="flex items-center gap-3">
                            <span className="text-sm font-bold text-gray-900 dark:text-white">₹{selectedOrder.totalAmount.toLocaleString()}</span>
                            <span className="text-xs text-gray-400 dark:text-zinc-500">Qty: {selectedOrder.quantity}</span>
                            {selectedOrder.size && <span className="text-xs text-gray-400 dark:text-zinc-500">Size: {selectedOrder.size}</span>}
                         </div>
                      </div>
                   </div>
                </div>

                <div className="flex justify-end gap-3 pt-4 font-sans">
                  <Button 
                    variant="outline"
                    className="h-9 px-4 border-[#e0122a] text-[#e0122a] hover:bg-red-50 dark:hover:bg-red-950/30 hover:text-[#0b0b0d] text-xs font-bold cursor-pointer transition-all active:scale-[0.98] rounded-md shadow-sm border-2"
                    onClick={() => {
                      setSelectedOrder(null);
                      navigate(`/product/${selectedOrder.product.id}`);
                    }}
                  >
                    Buy Again
                  </Button>
                  <Button 
                    className="h-9 px-4 bg-gray-900 dark:bg-zinc-100 hover:bg-black dark:hover:bg-white text-white dark:text-zinc-900 text-xs font-bold cursor-pointer transition-all active:scale-[0.98] border-none rounded-md shadow-sm"
                    onClick={() => setSelectedOrder(null)}
                  >
                    Close
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
